module.exports = [
    { "korisnickoIme": "ana", "lozinka": "anic" },
    { "korisnickoIme": "mate", "lozinka": "matic" },
    { "korisnickoIme": "duje", "lozinka": "dujic" }
];

