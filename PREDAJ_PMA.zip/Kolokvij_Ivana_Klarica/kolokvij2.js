document.addEventListener('DOMContentLoaded', function() {
    const forma = document.getElementById('forma');
    const poruka = document.getElementById('poruka');
    const noviBotun=document.getElementById('botun2');

    forma.addEventListener('submit', (e) => {
        e.preventDefault();

        const kor_ime = document.getElementById('korisnickoIme').value;
        const loz = document.getElementById('lozinka').value;

       fetch("http://localhost:4000/login", { method: 'POST',
                        headers: {
                            'Content-Type':'application/json',
                            'Accept':'*/*'
                        },
                        body: JSON.stringify({kor_ime, loz})})
        .then(res => res.json())
        .then(data => {
            if (data.uspjeh) {
                poruka.textContent=data.poruka;
                document.getElementById('uspjesnaPrijava').style.display='inline';
            }
            else {
                poruka.textContent=data.poruka;
            }
        })
        .catch(err => { console.log("Doslo je do pogreske: ",err)
        poruka.textContent="Doslo je do pogreske." })

})

noviBotun.addEventListener('click', e => {
    window.location.href="http://127.0.0.1:5500/kolokvij.html"
    
})


});