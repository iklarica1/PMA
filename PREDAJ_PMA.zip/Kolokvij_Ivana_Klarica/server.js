// server.js

const express = require("express");
const app = express();

app.use(function (req, res, next) {
    // Stranice (izvori) koji imaju pristup
    res.setHeader("Access-Control-Allow-Origin", "*");
    // Dozvoljene metode zahtjeva
    res.setHeader(
      "Access-Control-Allow-Methods",
      "GET, POST, OPTIONS, PUT, PATCH, DELETE"
    );
    // Dozvoljena zaglavlja zahjteva
    res.setHeader(
      "Access-Control-Allow-Headers",
      "X-Requested-With,content-type"
    );
    // Postaviti na TRUE ako je potrebno slanje cookie-ja uz zahtjev API-ju
    res.setHeader("Access-Control-Allow-Credentials", true);
    // Nastavi na iduci sloj
    next();
  });

const bodyParser = require("body-parser");

app.use(bodyParser.json());

let korisnici = require("./Korisnici");

app.post("/login", (req, res) => {
    const { kor_ime, loz } = req.body;
    console.log(`primljeni podaci ${kor_ime} i ${loz}`)

    // Provjera autentičnosti korisnika
    const pronadeniKorisnik = korisnici.find(korisnik => korisnik.korisnickoIme === kor_ime && korisnik.lozinka === loz);

    if (pronadeniKorisnik) {
        res.json({ uspjeh: true, poruka: "Uspješna prijava!" });
    } else {
        res.status(401).json({ uspjeh: false, poruka: "Neuspješna prijava!Taj korisnik ne postoji." });
    }
});

app.listen(4000, () => console.log("Server sluša na portu 4000!"));
